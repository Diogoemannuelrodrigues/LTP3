package br.com.projetoNatura.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.projetoNatura.conexao.conexao;
import br.com.projetoNatura.entidade.Produto;

public class ProdutoDao {
	
	public boolean cadastrarProduto(Produto produto){
		String sql = "insert into Produto (nome,descricao, preco) values (?,?,?)";
		Connection con = conexao.getConexao();
		
		if (con != null) {
			try {
				PreparedStatement stm = con.prepareStatement(sql);
				stm.setString(1, produto.getNome());
				stm.setString(2, produto.getDescricao());
				stm.setDouble(3, produto.getPreco());
				stm.execute();
				con.close();

			} catch (SQLException e) {
				return false;
			}
		
		return true;		
	}
		return false;
	
	}
	
	public static Produto consultarProduto(int codigoProduto){
		Connection con = conexao.getConexao();
		Produto produto = null;
		try{
			PreparedStatement stm = con.prepareStatement("select * from Produto where id = ?");
			stm.setInt(1, codigoProduto);
			ResultSet rs = stm.executeQuery();
			while(rs.next()){
				produto.setCodigoProduto(rs.getInt("codigoProduto"));
				produto.setNome(rs.getString("nome"));
				produto.setDescricao(rs.getString("descricao"));
				produto.setPreco(rs.getDouble("preco"));
			}
			rs.close();
			stm.close();
		}catch (SQLException e){
			e.printStackTrace();
		}		
		
		return produto;
		
	}
	
	
	public static void alterarProduto(Produto produto) {
		Connection con = conexao.getConexao();
		try {
			PreparedStatement stm = con.prepareStatement("UPDATE produto set nome = ?, descricao = ?, preco = ?");
			stm.setString(1, produto.getNome());
			stm.setString(2, produto.getDescricao());
			stm.setDouble(4, produto.getPreco());
			
			stm.execute();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public static void excluirProduto(Produto produto) {
		Connection con = conexao.getConexao();
		try {
			PreparedStatement ps = con.prepareStatement("DELETE FROM produto WHERE id = ? ");
			ps.setInt(1, produto.getCodigoProduto());
			ps.execute();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	public static List<Produto> Produtos(){
		Connection con = conexao.getConexao();
		String sql = "select * from Produto";
		
		List<Produto> lista = new ArrayList<Produto>();
			try{
				PreparedStatement stm = ((Connection) con).prepareStatement(sql);
				ResultSet sul = stm.executeQuery();
				while(sul.next()){
					Produto produto = new Produto();
					produto.setNome(sul.getString(1));
					produto.setCodigoProduto(sul.getInt(2));
					produto.setDescricao(sul.getString(3));
					produto.setPreco(sul.getDouble(4));
					
				}
			}catch (SQLException e){
				e.printStackTrace();
			}
		
		return Produtos();
		
		
		
	}
}