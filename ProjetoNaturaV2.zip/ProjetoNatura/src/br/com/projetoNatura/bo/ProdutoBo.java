package br.com.projetoNatura.bo;

import br.com.projetoNatura.Dao.ProdutoDao;
import br.com.projetoNatura.entidade.Produto;

public class ProdutoBo {

	ProdutoDao produtoDao = new ProdutoDao();

	public void cadastrarProduto(Produto produto) {
		produtoDao.cadastrarProduto(produto);

	}

	public Produto consultarProduto(int codigoProduto) {
		return produtoDao.consultarProduto(codigoProduto);

	}
	
	public void alterarProduto( Produto produto){
		produtoDao.alterarProduto(produto);
	}

}
