package br.com.teset;

import java.util.HashMap;
import java.util.Map;

import org.apache.jasper.tagplugins.jstl.core.ForEach;

import br.com.entidades.Cliente;
import br.com.entidades.Funcionario;
import br.com.entidades.Produto;

public class Teste {

	public static void main(String[] args) {
		
		Map<Object, String> adiciona = new HashMap<>();
		Funcionario fun = new Funcionario(12345, "Diogo", 91938330, "Planltina GO - ", "03389517170", "Diogo", " "); 
		Produto p1 = new Produto(1234, "Pedro", "Butijao de gas", 45.00, 2);
		Cliente c1 = new Cliente("Paulo", 91938330, "Brasilia", "9078563423");
	
		adiciona.put(fun, "funcionario");
		adiciona.put(p1, "Produto");
		adiciona.put(c1, "Clente");
		
			
			for (String string : args) {
				System.out.println(adiciona.get(string));
			}
	}

}
