package br.com.servlet.classe;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;

public class Oi extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	PrintWriter out = response.getWriter();
	 out.println("<html>");
	    out.println("<head>");
	    out.println("<title>Primeira Servlet</title>");
	    out.println("</head>");
	    out.println("<body>");
	    out.println("<h1>Oi mundo Servlet!</h1>");
	    out.println("</body>");
	    out.println("</html>");
    
    out.close();
	
    // buscando os parâmetros no request
    String nome = request.getParameter("nome");
    String endereco = request.getParameter("endereco");
    String email = request.getParameter("email");
    String dataEmTexto = request
            .getParameter("dataNascimento");
    Calendar dataNascimento = null;
    
    // fazendo a conversão da data
    try {
        Date date = (Date) new SimpleDateFormat("dd/MM/yyyy").parse(dataEmTexto);
        dataNascimento = Calendar.getInstance();
        dataNascimento.setTime(date);
    } catch (ParseException e) {
        out.println("Erro de conversão da data");
        return; //para a execução do método
    } catch (java.text.ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    
    
    out.println("<html>");
    out.println("<head>");
    out.println("<title>Primeira Servlet</title>");
    out.println("</head>");
    out.println("<body>");
    out.println("<h1>Oi mundo Servlet!</h1>");
    out.println("</body>");
    out.println("</html>");
	
    
    
	}

	
	
	
}
