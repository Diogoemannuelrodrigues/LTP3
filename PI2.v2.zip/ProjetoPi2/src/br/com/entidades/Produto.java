package br.com.entidades;


public final class Produto {
	private int codigo;
	private String nome;
	private String descricao;
	private Double preco;
	private int quantidade;
	//teria uma data de validade?????????

	public Produto(int codigo, String nome, String descricao, Double preco,
			int quantidade) {
		this.codigo = codigo;
		this.nome = nome;
		this.descricao = descricao;
		this.preco = preco;
		this.quantidade = quantidade;
	}

	public Integer getCodigo() {
		return codigo;
	}
	
	public String getNome() {
		return nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public Double getPreco() {
		return preco;
	}

	public Integer getQuantidade() {
		return quantidade;
	}

}