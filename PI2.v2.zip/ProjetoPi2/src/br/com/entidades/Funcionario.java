package br.com.entidades;

public class Funcionario {
	
	private int numeroId;
	private String nome;
	private long telefone;
	private String endereco;
	private String cpf;
	private String login;
	private String senha;
		
	public Funcionario(int numeroIdentificao, String nome, long telefone,
			String endereco, String cpf, String login, String senha) {
		this.numeroId = numeroIdentificao;
		this.nome = nome;
		this.telefone = telefone;
		this.endereco = endereco;
		this.cpf = cpf;
		this.login = login;
		this.senha = senha;
	}
	public int getNumeroIdentificao() {
		return numeroId;
	}
	public String getNome() {
		return nome;
	}
	public long getTelefone() {
		return telefone;
	}
	public String getEndereco() {
		return endereco;
	}
	public String getCpf() {
		return cpf;
	}
	public String getLogin() {
		return login;
	}
	public String getSenha() {
		return senha;
	}
	
	

}
