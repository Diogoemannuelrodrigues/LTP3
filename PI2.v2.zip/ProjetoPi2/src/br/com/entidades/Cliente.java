package br.com.entidades;

public class Cliente {
	
	private String nome;
	private long telefone;
	private String enderecoEntrega;
	private String cpf;
	
	public Cliente(String nome, long telefone, String enderecoEntrega,
			String cpf) {
		this.nome = nome;
		this.telefone = telefone;
		this.enderecoEntrega = enderecoEntrega;
		this.cpf = cpf;
	}
	public String getNome() {
		return nome;
	}
	public long getTelefone() {
		return telefone;
	}
	public String getEnderecoEntrega() {
		return enderecoEntrega;
	}
	public String getCpf() {
		return cpf;
	}
	
	
}
